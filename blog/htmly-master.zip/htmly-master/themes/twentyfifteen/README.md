# HTMLy Theme Twenty Fifteen
WordPress Twenty Fifteen ported to HTMLy.

## Installations 
 -  Upload and extract the zip file into themes directory.
 -  Activate it from HTMLy panel.

## License

See the LICENSE.txt
