# HTMLy Theme Twenty Sixteen
WordPress Twenty Sixteen ported to HTMLy.

## Installations 
 -  Upload and extract the zip file into themes directory.
 -  Activate it from HTMLy panel.

## License

See the LICENSE.txt
