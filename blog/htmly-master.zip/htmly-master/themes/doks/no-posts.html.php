<?php if (!defined('HTMLY')) die('HTMLy'); ?>
<article>
    <div class="blog-header">
        <h1>No posts found!</h1>
    </div>
    <div class="content-body">
        <p>Create a blog post or set the frontpage display to static page to remove this message.</p>
    </div>
</article>