# HTMLy Doks

Documentation theme by getdoks.org ported to HTMLy 

## Installations

 -  Upload and extract the zip file into themes directory.
 -  Activate it from HTMLy panel.
 
## Doks landing page

Go to `admin/config/reading` and choose `Front page displays` as `Static page`.

## License

See the LICENSE.txt
