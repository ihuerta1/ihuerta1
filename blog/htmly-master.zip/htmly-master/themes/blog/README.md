Original Theme Name: Developer

Author: Xiaoying Riley at 3rd Wave Media (http://themes.3rdwavemedia.com/)

Web: http://themes.3rdwavemedia.com/

Email: hello[@]3rdwavemedia.com

Twitter: @3rdwave_themes

Ported and modified by: HTMLy Team
