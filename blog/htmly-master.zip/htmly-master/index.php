<?php
define('HTMLY', true);
define('HTMLY_VERSION', 'v2.9.9');
$config_file = 'config/config.ini';
require 'system/vendor/autoload.php';
require 'system/htmly.php';
