## Security Policy

### Reporting Vulnerability

Please report any security vulnerabilities to **[dan@danpros.com](mailto:dan@danpros.com)**. If we can confirm the issue, we will release a patch as soon as possible.
